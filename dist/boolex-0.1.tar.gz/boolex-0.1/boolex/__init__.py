from .main import bool_to_regex
